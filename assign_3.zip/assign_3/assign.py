import requests
from bs4 import BeautifulSoup
import csv

search_query = "site:youtube.com openinapp.co"
url = f"https://www.google.com/search?q={search_query}&num=100"
headers = {
    "User-Agent": "Chrome/88.0.4324.150 "
    }

results = []
count = 0
while count < 10000:
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, "html.parser")
    links = soup.find_all("a")

    for link in links:
        href = link.get("href")
        if href.startswith("/url?q=https://www.youtube.com/channel/"):
            channel_link = href.split("/url?q=")[1].split("&")[0]
            results.append(channel_link)
            count += 1

            if count >= 10000:
                break

    next_page = soup.find("a", {"id": "pnnext"})
    if next_page:
        url = "https://www.google.com" + next_page.get("href")
    else:
        break


with open("results.csv", "w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(["YouTube Channel Links"])
    writer.writerows([[link] for link in results])
